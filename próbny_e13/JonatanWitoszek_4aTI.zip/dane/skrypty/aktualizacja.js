﻿function czas(){

	document.write(document.lastModified)

}
czas()